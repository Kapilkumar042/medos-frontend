import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  Users,
  CalendarDays,
  Wallet,
  BedDouble,
  TestTube,
  Pill,
  AlertCircle,
  TrendingUp,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { MetricCard } from "@/components/shared/MetricCard";
import { PageHeader } from "@/components/shared/PageHeader";
import {
  collectionData,
  sparkData,
  appointments,
  beds,
  findPatient,
  findDoctor,
} from "@/lib/mock-data";
import { Badge } from "@/components/ui/badge";
import { inr, num } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { dashboardApi } from "@/api/dashboardApi";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import type { DateRange } from "react-day-picker";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
});

type DashboardPeriod =
  | "today"
  | "yesterday"
  | "this_week"
  | "this_month"
  | "this_year"
  | "custom";

function formatDate(date: Date) {
  return date.toISOString().slice(0, 10);
}

function getRange(period: DashboardPeriod): DateRange {
  const today = new Date();
  const from = new Date(today);
  const to = new Date(today);

  if (period === "yesterday") {
    from.setDate(today.getDate() - 1);
    to.setDate(today.getDate() - 1);
  } else if (period === "this_week") {
    const mondayOffset = today.getDay() === 0 ? 6 : today.getDay() - 1;
    from.setDate(today.getDate() - mondayOffset);
  } else if (period === "this_month") {
    from.setDate(1);
  } else if (period === "this_year") {
    from.setMonth(0, 1);
  }

  return { from, to };
}

type DashboardData = {
  patients_registered_in_period?: number;
  total_visits?: number;
  collection_in_period?: number;
  outstanding_due_all_time?: number;
  pharmacy_sales?: number;
  lab_tests?: number;
  admissions_in_period?: number;
  total_collection_in_period?: number;
  occupied_beds?: number;
  available_beds?: number;
  total_beds?: number;
  revenue_data?: Array<{
    month: string;
    revenue: number;
    expense: number;
  }>;
  monthly_volume?: Array<{
    month: string;
    opd: number;
    ipd: number;
  }>;
  department_performance?: Array<{
    dept: string;
    patients: number;
  }>;
};

const tooltipStyle = {
  contentStyle: {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: "12px",
    fontSize: "12px",
  },
};

function Dashboard() {
  const todayAppts = appointments.slice(0, 6);
  const occupiedBeds = beds.filter((b) => b.status === "Occupied").length;
  const availableBeds = beds.filter((b) => b.status === "Available").length;
const [period, setPeriod] = useState<DashboardPeriod>("today");
const [dateRange, setDateRange] = useState<DateRange>(() =>
  getRange("today"),
);
  const [opdData, setOpdData] = useState<DashboardData | null>(null);
const [ipdData, setIpdData] = useState<DashboardData | null>(null);
const [dashboardLoading, setDashboardLoading] = useState(true);
const [dashboardError, setDashboardError] = useState(false);

useEffect(() => {
  let active = true;

  async function loadDashboard() {
    setDashboardLoading(true);
    setDashboardError(false);

    const params =
      period === "custom"
        ? {
            period,
            start_date: dateRange.from
              ? formatDate(dateRange.from)
              : undefined,
            end_date: dateRange.to
              ? formatDate(dateRange.to)
              : dateRange.from
                ? formatDate(dateRange.from)
                : undefined,
          }
        : { period };

    try {
      const [opd, ipd] = await Promise.all([
        dashboardApi.getOpd(params),
        dashboardApi.getIpd(params),
      ]);

      if (!active) return;

      setOpdData(opd.data ?? opd);
      setIpdData(ipd.data ?? ipd);
    } catch (error) {
      console.error("Failed to load dashboard", error);

      if (active) {
        setDashboardError(true);
        setOpdData(null);
        setIpdData(null);
      }
    } finally {
      if (active) {
        setDashboardLoading(false);
      }
    }
  }

  void loadDashboard();

  return () => {
    active = false;
  };
}, [period, dateRange]);
const selectedPeriodLabel = period.replaceAll("_", " ");

const collectionChartData = [
  { name: "OPD", amount: Number(opdData?.collection_in_period ?? 0) },
  { name: "IPD", amount: Number(ipdData?.collection_in_period ?? 0) },
];

const volumeChartData = [
  {
    period: selectedPeriodLabel,
    opd: Number(opdData?.patients_registered_in_period ?? 0),
    ipd: Number(ipdData?.admissions_in_period ?? 0),
  },
];

const paymentTotals = new Map<string, number>();

for (const source of [
  opdData?.collection_by_payment_mode,
  ipdData?.collection_by_payment_mode,
]) {
  for (const [mode, amount] of Object.entries(source ?? {})) {
    const normalizedMode = mode.trim().toUpperCase();
    paymentTotals.set(
      normalizedMode,
      (paymentTotals.get(normalizedMode) ?? 0) + Number(amount || 0),
    );
  }
}

const paymentTotal = [...paymentTotals.values()].reduce(
  (sum, amount) => sum + amount,
  0,
);

const paymentMixData = [...paymentTotals.entries()].map(([name, amount], index) => ({
  name,
  amount,
  value: paymentTotal > 0 ? (amount / paymentTotal) * 100 : 0,
  fill: `var(--chart-${(index % 5) + 1})`,
}));

const duesChartData = [
  { name: "OPD outstanding", amount: Number(opdData?.outstanding_due_all_time ?? 0) },
  { name: "IPD outstanding", amount: Number(ipdData?.outstanding_due_all_time ?? 0) },
];

const revenueChartData = opdData?.revenue_data ?? [];
const monthlyVolumeData = opdData?.monthly_volume ?? [];
const departmentData = opdData?.department_performance ?? [];

  return (
    <>
      <PageHeader
  title="Dashboard"
  description="Real-time overview of your hospital operations."
>
  <div className="flex flex-wrap items-center gap-2">
    <select
      value={period}
      onChange={(event) => {
        const selectedPeriod = event.target.value as DashboardPeriod;
        setPeriod(selectedPeriod);

        if (selectedPeriod !== "custom") {
          setDateRange(getRange(selectedPeriod));
        }
      }}
      className="h-9 rounded-md border border-input bg-background px-3 text-sm"
    >
      <option value="today">Today</option>
      <option value="yesterday">Yesterday</option>
      <option value="this_week">This Week</option>
      <option value="this_month">This Month</option>
      <option value="this_year">This Year</option>
      <option value="custom">Custom Range</option>
    </select>

    {period === "custom" && (
      <Popover>
        <PopoverTrigger asChild>
          <Button type="button" variant="outline" className="h-9">
            <CalendarDays className="mr-2 h-4 w-4" />
            {dateRange.from
              ? `${formatDate(dateRange.from)} - ${formatDate(
                  dateRange.to ?? dateRange.from,
                )}`
              : "Choose dates"}
          </Button>
        </PopoverTrigger>

        <PopoverContent className="w-auto p-0" align="end">
          <Calendar
            mode="range"
            numberOfMonths={2}
            selected={dateRange}
            onSelect={(range) => {
              if (range?.from) {
                setDateRange(range);
              }
            }}
          />
        </PopoverContent>
      </Popover>
    )}
  </div>

  <Badge variant="outline" className="bg-success/10 text-success border-success/30 gap-1">
    <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
    Live
  </Badge>

  <Button variant="outline" size="sm">
    Export Report
  </Button>
</PageHeader>

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
        <MetricCard
  label="OPD Patients"
  value={dashboardLoading ? "..." : num(opdData?.patients_registered_in_period ?? 0)}
  icon={Users}
  gradient="teal"
  index={0}
/>

<MetricCard
  label="IPD Patients"
  value={dashboardLoading ? "..." : num(ipdData?.admissions_in_period ?? 0)}
  icon={BedDouble}
  gradient="blue"
  index={1}
/>

<MetricCard
  label="OPD Revenue Today"
  value={dashboardLoading ? "..." : inr(opdData?.collection_in_period ?? 0)}
  icon={Wallet}
  gradient="success"
  index={3}
/>
<MetricCard
  label="IPD Revenue Today"
  value={dashboardLoading ? "..." : inr(ipdData?.total_collection_in_period ?? 0)}
  icon={Wallet}
  gradient="success"
  index={3}
/>

<MetricCard
  label="OPD Pending Bills"
  value={dashboardLoading ? "..." : inr(opdData?.outstanding_due_all_time ?? 0)}
  icon={AlertCircle}
  gradient="warning"
  index={4}
/>

<MetricCard
  label="IPD Outstanding"
  value={
    dashboardLoading
      ? "..."
      : inr(Number(ipdData?.outstanding_due_all_time ?? 0))
  }
  icon={AlertCircle}
  gradient="warning"
  index={5}
/>

<MetricCard
  label="Available Beds"
  value={`${ipdData?.available_beds ?? 0}/${ipdData?.total_beds ?? 0}`}
  icon={BedDouble}
  gradient="teal"
  index={5}
/>

<MetricCard
  label="Pharmacy Sales"
  value={dashboardLoading ? "..." : inr(opdData?.pharmacy_sales ?? 0)}
  icon={Pill}
  gradient="blue"
  index={6}
/>

<MetricCard
  label="Lab Tests Today"
  value={dashboardLoading ? "..." : num(opdData?.lab_tests ?? 0)}
  icon={TestTube}
  gradient="success"
  index={7}
/>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-6">
        <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="lg:col-span-2 rounded-2xl bg-card border border-border shadow-soft p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold">Revenue vs Expense</h3>
              <p className="text-xs text-muted-foreground">Last 12 months</p>
            </div>
            <Badge variant="outline" className="text-success border-success/30 bg-success/10 gap-1">
              <TrendingUp className="h-3 w-3" /> +18.2%
            </Badge>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={revenueChartData}>
              <defs>
                <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="exp" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-5)" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="var(--chart-5)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={11} />
              <YAxis stroke="var(--muted-foreground)" fontSize={11} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
              <Tooltip {...tooltipStyle} />
              <Area type="monotone" dataKey="revenue" stroke="var(--chart-1)" strokeWidth={2.5} fill="url(#rev)" />
              <Area type="monotone" dataKey="expense" stroke="var(--chart-5)" strokeWidth={2.5} fill="url(#exp)" />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
          className="rounded-2xl bg-card border border-border shadow-soft p-5"
        >
          <h3 className="font-semibold mb-1">Collection Mix</h3>
          <p className="text-xs text-muted-foreground mb-4">Cash vs Online</p>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={paymentMixData} dataKey="value" innerRadius={50} outerRadius={80} paddingAngle={3}>
                {paymentMixData.map((d, i) => <Cell key={i} fill={d.fill} />)}
              </Pie>
              <Tooltip {...tooltipStyle} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {collectionData.map((d) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full" style={{ background: d.fill }} />
                  {d.name}
                </div>
                <span className="font-medium">{d.value}%</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
        <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="rounded-2xl bg-card border border-border shadow-soft p-5"
        >
          <h3 className="font-semibold">OPD vs IPD</h3>
          <p className="text-xs text-muted-foreground mb-4">Monthly volume</p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={volumeChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={11} />
              <YAxis stroke="var(--muted-foreground)" fontSize={11} />
              <Tooltip {...tooltipStyle} />
              <Line type="monotone" dataKey="opd" stroke="var(--chart-1)" strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="ipd" stroke="var(--chart-2)" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
          className="rounded-2xl bg-card border border-border shadow-soft p-5"
        >
          <h3 className="font-semibold">Department Performance</h3>
          <p className="text-xs text-muted-foreground mb-4">Patients this month</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={departmentData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="dept" stroke="var(--muted-foreground)" fontSize={10} interval={0} angle={-25} textAnchor="end" height={60} />
              <YAxis stroke="var(--muted-foreground)" fontSize={11} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="patients" fill="var(--chart-2)" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="rounded-2xl bg-card border border-border shadow-soft p-5"
        >
          <h3 className="font-semibold">Bed Occupancy</h3>
          <p className="text-xs text-muted-foreground mb-4">{occupiedBeds} of {beds.length} occupied</p>
          <div className="flex items-center justify-center mb-3">
            <div className="relative h-32 w-32">
              <svg viewBox="0 0 100 100" className="-rotate-90 h-full w-full">
                <circle cx="50" cy="50" r="42" stroke="var(--muted)" strokeWidth="10" fill="none" />
                <circle
                  cx="50" cy="50" r="42"
                  stroke="var(--chart-1)" strokeWidth="10" fill="none"
                  strokeDasharray={`${(occupiedBeds / beds.length) * 264} 264`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-2xl font-semibold">{Math.round((occupiedBeds / beds.length) * 100)}%</span>
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Occupied</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {(["ICU", "General", "Private", "Pediatric"] as const).map((w) => {
              const count = beds.filter((b) => b.ward === w && b.status === "Occupied").length;
              const total = beds.filter((b) => b.ward === w).length;
              return (
                <div key={w} className="rounded-lg bg-muted/40 p-2">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{w}</div>
                  <div className="font-medium">{count}/{total}</div>
                </div>
              );
            })}
          </div>
        </motion.div> */}
      </div>

      {/* <motion.div
        initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
        className="rounded-2xl bg-card border border-border shadow-soft p-5 mt-4"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-semibold">Today's Appointments</h3>
            <p className="text-xs text-muted-foreground">Live queue</p>
          </div>
        </div>
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground uppercase tracking-wider">
              <tr>
                <th className="text-left py-2">Token</th>
                <th className="text-left py-2">Patient</th>
                <th className="text-left py-2">Doctor</th>
                <th className="text-left py-2">Department</th>
                <th className="text-left py-2">Time</th>
                <th className="text-left py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {todayAppts.map((a) => {
                const p = findPatient(a.patientId);
                const d = findDoctor(a.doctorId);
                return (
                  <tr key={a.id} className="border-t border-border">
                    <td className="py-2.5 font-mono text-xs">#{a.token}</td>
                    <td className="py-2.5 font-medium">{p?.name}</td>
                    <td className="py-2.5">{d?.name}</td>
                    <td className="py-2.5 text-muted-foreground">{a.department}</td>
                    <td className="py-2.5">{a.time}</td>
                    <td className="py-2.5">
                      <Badge
                        variant="outline"
                        className={
                          a.status === "Completed" ? "border-success text-success" :
                          a.status === "In Consultation" ? "border-info text-info" :
                          a.status === "Cancelled" ? "border-destructive text-destructive" :
                          "border-warning text-warning"
                        }
                      >
                        {a.status}
                      </Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </motion.div> */}
    </>
  );
}

export const _u = { Legend };
