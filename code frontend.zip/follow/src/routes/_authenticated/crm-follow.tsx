import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import { Activity, Archive, CalendarDays, Check, Clock3, Download, Eye, FileUp, Megaphone, MoreVertical, PhoneCall, Plus, RotateCcw, Search, Trash2, Users } from "lucide-react";
import { followUpApi } from "@/api/follow-up-api";
import type { FollowUpInput } from "@/api/follow-up-api";
import { opdApi } from "@/lib/opd-api";
import {
  type FollowUpPatient,
  FOLLOWUP_STATUSES,
  type FollowUpStatus,
  type FollowUpType,
  type InvestigationStatus,
  type CallOutcome,
} from "@/store/followUpStore";
import { PageHeader } from "@/components/shared/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/crm-follow")({
  component: CrmFollowPage,
  validateSearch: (search: Record<string, unknown>) => ({
    view: search.view === "external" || search.view === "leads" ? search.view : "internal",
  }),
});

type ModuleTab = "internal" | "external" | "leads";
type PatientRow = {
  id: string;
  uhid: string;
  encounterId: string;
  name: string;
  phone: string;
  age?: number;
  doctorName: string;
  departmentName: string;
};
type CampaignLead = {
  id: string;
  name: string;
  phone: string;
  channel: string;
  campaign: string;
  interest: string;
  received: string;
  stage: "New" | "Contacted" | "Qualified" | "Converted";
  owner: string;
};

const investigationStatuses: InvestigationStatus[] = [
  "Not Required",
  "Pending",
  "Report Available",
  "Reviewed",
];

const mockCampaignLeads: CampaignLead[] = [
  { id: "SOC-24081", name: "Ananya Mehta", phone: "+91 98765 01432", channel: "Instagram", campaign: "Women's wellness screening", interest: "Gynaecology", received: "2026-10-06T09:20:00", stage: "New", owner: "Unassigned" },
  { id: "SOC-24080", name: "Rohan Verma", phone: "+91 98765 01433", channel: "Facebook", campaign: "Heart health week", interest: "Cardiology", received: "2026-10-06T08:45:00", stage: "Contacted", owner: "Front desk" },
  { id: "SOC-24074", name: "Meera Joshi", phone: "+91 98765 01434", channel: "Instagram", campaign: "Joint pain consultation", interest: "Orthopaedics", received: "2026-10-05T16:10:00", stage: "Qualified", owner: "OPD desk" },
  { id: "SOC-24069", name: "Karan Singh", phone: "+91 98765 01435", channel: "Facebook", campaign: "Preventive health check", interest: "Health Check-up", received: "2026-10-05T13:35:00", stage: "Converted", owner: "OPD desk" },
  { id: "SOC-24061", name: "Sana Khan", phone: "+91 98765 01436", channel: "Instagram", campaign: "Skin and allergy clinic", interest: "Dermatology", received: "2026-10-04T11:05:00", stage: "New", owner: "Unassigned" },
];

const blankFollowUp = {
  patientId: "",
  uhid: "",
  encounterId: "",
  name: "",
  phone: "",
  age: "",
  doctorName: "",
  departmentName: "",
  followUpType: "OPD_REVIEW" as FollowUpType,
  query: "",
  nextDate: "",
  investigationStatus: "Not Required" as InvestigationStatus,
  investigationName: "",
  investigationOrderId: "",
  procedureName: "",
  procedureDate: "",
  dischargeDate: "",
};

const statusClasses: Record<FollowUpStatus, string> = {
  Pending: "border-border bg-muted text-muted-foreground",
  Scheduled: "border-blue-500/30 bg-blue-500/10 text-blue-700 dark:text-blue-300",
  Confirmed: "border-primary/30 bg-primary/10 text-primary",
  "Checked In": "border-cyan-500/30 bg-cyan-500/10 text-cyan-700",
  "In Consultation": "border-indigo-500/30 bg-indigo-500/10 text-indigo-700",
  Completed: "border-emerald-500/30 bg-emerald-500/10 text-emerald-700",
  Missed: "border-destructive/30 bg-destructive/10 text-destructive",
  Cancelled: "border-border bg-muted text-muted-foreground",
  Rescheduled: "border-amber-500/30 bg-amber-500/10 text-amber-700",
  "Not Reachable": "border-orange-500/30 bg-orange-500/10 text-orange-700",
  "Call Back": "border-amber-500/30 bg-amber-500/10 text-amber-700",
  "Not Interested": "border-destructive/30 bg-destructive/10 text-destructive",
};

function normalizePatient(patient: any): PatientRow {
  return {
    id: String(patient.id ?? ""),
    uhid: String(patient.uhid ?? patient.UHID ?? ""),
    encounterId: String(patient.opd_no ?? patient.opdNo ?? patient.encounter_id ?? ""),
    name: String(patient.name ?? patient.patient_name ?? ""),
    phone: String(patient.mobile ?? patient.phone ?? ""),
    age: Number(patient.age) || undefined,
    doctorName: String(patient.doctor_name ?? patient.doctor?.name ?? patient.doctorName ?? ""),
    departmentName: String(patient.department ?? patient.department_name ?? ""),
  };
}

function dateLabel(date?: string) {
  if (!date) return "Not scheduled";
  const parsed = new Date(date);
  return Number.isNaN(parsed.getTime())
    ? "Not scheduled"
    : new Intl.DateTimeFormat("en", { day: "2-digit", month: "short", year: "numeric" }).format(parsed);
}

function CrmFollowPage() {
  const navigate = useNavigate();
  const { view: tab } = Route.useSearch();
  const [search, setSearch] = useState("");
  const [registeredPatients, setRegisteredPatients] = useState<PatientRow[]>([]);
  const [followUps, setFollowUps] = useState<FollowUpPatient[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [externalDialogOpen, setExternalDialogOpen] = useState(false);
  const [internalPatient, setInternalPatient] = useState<PatientRow | null>(null);
  const [followUpForm, setFollowUpForm] = useState({ ...blankFollowUp });
  const [selectedExternal, setSelectedExternal] = useState<string[]>([]);
  const [showArchivedExternal, setShowArchivedExternal] = useState(false);
  const [statusDialog, setStatusDialog] = useState<{ ids: string[]; status: FollowUpStatus } | null>(null);
  const [recordResult, setRecordResult] = useState("");
  const [recordNextDate, setRecordNextDate] = useState("");
  const [recordComplaint, setRecordComplaint] = useState("");
  const [recordDiagnosis, setRecordDiagnosis] = useState("");
  const [recordDoctorNotes, setRecordDoctorNotes] = useState("");
  const [recordTreatmentPlan, setRecordTreatmentPlan] = useState("");
  const [recordInvestigationStatus, setRecordInvestigationStatus] = useState<InvestigationStatus>("Not Required");
  const [recordInvestigationName, setRecordInvestigationName] = useState("");
  const [recordInvestigationOrderId, setRecordInvestigationOrderId] = useState("");
  const [callPatient, setCallPatient] = useState<FollowUpPatient | null>(null);
  const [callOutcome, setCallOutcome] = useState<CallOutcome>("Answered");
  const [callNotes, setCallNotes] = useState("");
  const [nextCallAt, setNextCallAt] = useState("");
  const [historyPatient, setHistoryPatient] = useState<FollowUpPatient | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const refresh = async () => {
    const [patientResponse, followUpResponse] = await Promise.all([
      opdApi.listPatients().catch((error) => {
        console.error(error);
        toast.error("Failed to load registered patients");
        return [];
      }),
      followUpApi.list().catch((error) => {
        console.error(error);
        toast.error("Failed to load follow-ups");
        return [];
      }),
    ]);
    setRegisteredPatients(
      patientResponse
        .map((patient: unknown) => normalizePatient(patient))
        .filter((patient: PatientRow) => patient.id),
    );
    setFollowUps(followUpResponse);
  };

  useEffect(() => {
    void refresh().finally(() => setLoading(false));
  }, []);

  const normalizedSearch = search.trim().toLowerCase();
  const visibleInternalPatients = useMemo(
    () => registeredPatients.filter((patient) =>
      [patient.name, patient.phone, patient.uhid, patient.encounterId, patient.doctorName]
        .some((value) => value.toLowerCase().includes(normalizedSearch)),
    ),
    [registeredPatients, normalizedSearch],
  );
  const allInternalFollowUps = useMemo(
    () => followUps.filter((item) =>
      item.createdBy === "CRM_INTERNAL" || (item.createdBy !== "CRM_EXTERNAL" && Boolean(item.patientId)),
    ),
    [followUps],
  );
  const internalFollowUps = useMemo(() => allInternalFollowUps.filter((item) => !item.archived), [allInternalFollowUps]);
  const allExternalFollowUps = useMemo(
    () => followUps.filter((item) =>
      item.createdBy === "CRM_EXTERNAL" || (item.createdBy !== "CRM_INTERNAL" && !item.patientId),
    ),
    [followUps],
  );
  const externalFollowUps = useMemo(() => allExternalFollowUps.filter((item) => !item.archived), [allExternalFollowUps]);
  const archivedExternalFollowUps = useMemo(() => allExternalFollowUps.filter((item) => item.archived), [allExternalFollowUps]);
  const displayedExternalFollowUps = showArchivedExternal ? archivedExternalFollowUps : externalFollowUps;
  const visibleExternalFollowUps = useMemo(
    () => displayedExternalFollowUps.filter((item) =>
      [item.name, item.phone, item.uhid, item.doctorName, item.departmentName]
        .some((value) => (value ?? "").toLowerCase().includes(normalizedSearch)),
    ),
    [displayedExternalFollowUps, normalizedSearch],
  );
  const existingForPatient = (patient: PatientRow) =>
    internalFollowUps.find((item) =>
      (item.patientId && item.patientId === patient.id) ||
      (patient.uhid && item.uhid === patient.uhid),
    );
  const archivedForPatient = (patient: PatientRow) =>
    allInternalFollowUps.find((item) =>
      item.archived && ((item.patientId && item.patientId === patient.id) || (patient.uhid && item.uhid === patient.uhid)),
    );

  const resetFollowUpForm = () => setFollowUpForm({ ...blankFollowUp });
  const openInternalFollowUp = (patient: PatientRow) => {
    setInternalPatient(patient);
    const current = existingForPatient(patient);
    setFollowUpForm({
      ...blankFollowUp,
      patientId: patient.id,
      uhid: patient.uhid,
      encounterId: patient.encounterId,
      name: patient.name,
      phone: patient.phone,
      age: patient.age ? String(patient.age) : "",
      doctorName: patient.doctorName,
      departmentName: patient.departmentName,
      followUpType: current?.followUpType ?? "OPD_REVIEW",
      query: current?.query ?? "",
      nextDate: current?.nextDate ?? "",
    });
  };

  const saveInternalFollowUp = async () => {
    if (!internalPatient) return;
    setSaving(true);
    try {
      const existing = existingForPatient(internalPatient);
      if (existing) {
        await followUpApi.recordOne(existing.id, {
          status: "Scheduled",
          result: followUpForm.query.trim() || "Internal follow-up scheduled",
          nextDate: followUpForm.nextDate || undefined,
          createdBy: "CRM_INTERNAL",
        });
      } else {
        await followUpApi.create({ ...followUpInput(followUpForm), createdBy: "CRM_INTERNAL" });
      }
      await refresh();
      setInternalPatient(null);
      toast.success(existing ? "Internal follow-up updated" : "Internal follow-up created");
    } catch (error) {
      console.error(error);
      toast.error("Could not save internal follow-up");
    } finally {
      setSaving(false);
    }
  };

  const saveExternalFollowUp = async () => {
    if (!followUpForm.name.trim() || !followUpForm.phone.trim()) {
      toast.error("Patient name and phone are required");
      return;
    }
    if (followUpForm.followUpType === "INVESTIGATION_REVIEW" && !followUpForm.investigationName.trim()) {
      toast.error("Investigation name is required");
      return;
    }
    setSaving(true);
    try {
      await followUpApi.create({ ...followUpInput(followUpForm), createdBy: "CRM_EXTERNAL" });
      await refresh();
      resetFollowUpForm();
      setExternalDialogOpen(false);
      toast.success("External follow-up added");
    } catch (error) {
      console.error(error);
      toast.error("Could not add external follow-up");
    } finally {
      setSaving(false);
    }
  };

  const openStatusUpdate = (ids: string[], status: FollowUpStatus, item?: FollowUpPatient) => {
    setRecordResult(item?.logs.at(-1)?.result ?? item?.query ?? "");
    setRecordNextDate(item?.nextDate ?? "");
    setRecordComplaint(item?.logs.at(-1)?.currentComplaint ?? "");
    setRecordDiagnosis(item?.logs.at(-1)?.diagnosis ?? "");
    setRecordDoctorNotes(item?.logs.at(-1)?.doctorNotes ?? "");
    setRecordTreatmentPlan(item?.logs.at(-1)?.treatmentPlan ?? "");
    setRecordInvestigationStatus(item?.investigationStatus ?? "Not Required");
    setRecordInvestigationName(item?.investigationName ?? "");
    setRecordInvestigationOrderId(item?.investigationOrderId ?? "");
    setStatusDialog({ ids, status });
  };

  const saveStatusUpdate = async () => {
    if (!statusDialog) return;
    if (!recordResult.trim()) {
      toast.error("Enter follow-up result");
      return;
    }

    setSaving(true);
    try {
      await followUpApi.record(statusDialog.ids, {
        status: statusDialog.status,
        result: recordResult.trim(),
        nextDate: recordNextDate || undefined,
        currentComplaint: recordComplaint.trim() || undefined,
        diagnosis: recordDiagnosis.trim() || undefined,
        doctorNotes: recordDoctorNotes.trim() || undefined,
        treatmentPlan: recordTreatmentPlan.trim() || undefined,
        investigationStatus: recordInvestigationStatus,
        investigationName: recordInvestigationName.trim() || undefined,
        investigationOrderId: recordInvestigationOrderId.trim() || undefined,
        createdBy: "CRM",
      });
      await refresh();
      setStatusDialog(null);
      setSelectedExternal([]);
      toast.success("Follow-up status saved");
    } catch (error) {
      console.error(error);
      toast.error("Could not update follow-up status");
    } finally {
      setSaving(false);
    }
  };

  const saveCall = async () => {
    if (!callPatient) return;
    if (!callNotes.trim()) {
      toast.error("Enter call notes");
      return;
    }

    setSaving(true);
    try {
      await followUpApi.addCall(callPatient.id, {
        outcome: callOutcome,
        notes: callNotes.trim(),
        calledBy: "Current User",
        nextCallAt: nextCallAt ? new Date(nextCallAt).toISOString() : undefined,
      });
      await refresh();
      setCallPatient(null);
      toast.success("Call history saved");
    } catch (error) {
      console.error(error);
      toast.error("Could not save call history");
    } finally {
      setSaving(false);
    }
  };

  const archiveExternal = async (ids: string[]) => {
    try {
      await Promise.all(ids.map((id) => followUpApi.setArchived(id, true)));
      await refresh();
      setSelectedExternal([]);
      toast.success(ids.length === 1 ? "Follow-up archived" : "Selected follow-ups archived");
    } catch (error) {
      console.error(error);
      toast.error("Could not archive follow-ups");
    }
  };

  const restoreExternal = async (id: string) => {
    try {
      await followUpApi.restore(id);
      await refresh();
      toast.success("Follow-up restored");
    } catch (error) {
      console.error(error);
      toast.error("Could not restore follow-up");
    }
  };

  const deleteExternal = async (id: string) => {
    try {
      await followUpApi.remove(id);
      await refresh();
      setSelectedExternal((current) => current.filter((selectedId) => selectedId !== id));
      toast.success("Follow-up deleted");
    } catch (error) {
      console.error(error);
      toast.error("Could not delete follow-up");
    }
  };

  const handleExternalImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      if (!sheet) {
        toast.error("Excel sheet not found");
        return;
      }
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });
      const get = (row: Record<string, unknown>, ...names: string[]) => {
        const key = Object.keys(row).find((name) => names.includes(name.trim().toLowerCase()));
        return key ? String(row[key]).trim() : "";
      };
      const normalizeType = (value: string): FollowUpType => {
        const normalized = value.toLowerCase().replaceAll(" ", "_");
        if (normalized === "investigation_review" || normalized === "report_review") return "INVESTIGATION_REVIEW";
        if (normalized === "post_procedure" || normalized === "post-surgery") return "POST_PROCEDURE";
        return "OPD_REVIEW";
      };
      const parsed: FollowUpInput[] = rows.map((row) => {
        const investigationStatus = get(row, "investigation status") as InvestigationStatus;
        return {
          patientId: get(row, "patient id") || undefined,
          uhid: get(row, "uhid") || undefined,
          encounterId: get(row, "encounter id") || undefined,
          name: get(row, "patient name", "name"),
          phone: get(row, "phone", "mobile"),
          age: Number(get(row, "age")) || undefined,
          doctorName: get(row, "doctor", "doctor name") || undefined,
          departmentName: get(row, "department", "department name") || undefined,
          followUpType: normalizeType(get(row, "follow-up type", "followup type", "type")),
          query: get(row, "patient query", "query", "reason"),
          nextDate: get(row, "next date", "follow-up date") || undefined,
          investigationStatus: investigationStatuses.includes(investigationStatus) ? investigationStatus : "Not Required",
          investigationName: get(row, "investigation name") || undefined,
          investigationOrderId: get(row, "investigation order id", "order id") || undefined,
          procedureName: get(row, "procedure name") || undefined,
          procedureDate: get(row, "procedure date") || undefined,
          dischargeDate: get(row, "discharge date") || undefined,
          createdBy: "CRM_EXTERNAL",
        };
      }).filter((row) => row.name && row.phone);
      if (!parsed.length) {
        toast.error("No rows with patient name and phone were found");
        return;
      }
      const result = await followUpApi.importRows(parsed);
      await refresh();
      toast.success(`Imported ${result?.created?.length ?? parsed.length} external follow-up(s)`);
    } catch (error) {
      console.error(error);
      toast.error("Could not import external follow-ups");
    } finally {
      event.target.value = "";
    }
  };

  const downloadExternalTemplate = () => {
    const sheet = XLSX.utils.aoa_to_sheet([[
      "Patient ID", "UHID", "Encounter ID", "Patient Name", "Phone", "Age", "Doctor",
      "Department", "Follow-Up Type", "Patient Query", "Next Date", "Investigation Status",
      "Investigation Name", "Investigation Order ID", "Procedure Name", "Procedure Date", "Discharge Date",
    ]]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, "External Follow-Up");
    XLSX.writeFile(workbook, "crm-external-follow-up-template.xlsx");
  };

  const exportExternal = () => {
    const rows = visibleExternalFollowUps.map((item) => ({
      "Patient ID": item.patientId ?? "",
      UHID: item.uhid ?? "",
      "Encounter ID": item.encounterId ?? "",
      "Patient Name": item.name,
      Phone: item.phone,
      Age: item.age ?? "",
      Doctor: item.doctorName ?? "",
      Department: item.departmentName ?? "",
      "Follow-Up Type": item.followUpType ?? "OPD_REVIEW",
      "Patient Query": item.query,
      "Next Date": item.nextDate ?? "",
      Status: item.status,
      "Investigation Status": item.investigationStatus ?? "Not Required",
      "Investigation Name": item.investigationName ?? "",
      "Investigation Order ID": item.investigationOrderId ?? "",
      "Procedure Name": item.procedureName ?? "",
      "Procedure Date": item.procedureDate ?? "",
      "Discharge Date": item.dischargeDate ?? "",
    }));
    const sheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, "External Follow-Up");
    XLSX.writeFile(workbook, "crm-external-follow-ups.xlsx");
  };

  const selectExternal = (id: string) => setSelectedExternal((current) =>
    current.includes(id) ? current.filter((selectedId) => selectedId !== id) : [...current, id],
  );
  const mockLeadSearch = useMemo(() => mockCampaignLeads.filter((lead) =>
    [lead.name, lead.phone, lead.channel, lead.campaign, lead.interest, lead.stage]
      .some((value) => value.toLowerCase().includes(normalizedSearch)),
  ), [normalizedSearch]);
  const tabCounts = { internal: registeredPatients.length, external: externalFollowUps.length, leads: mockCampaignLeads.length };

  return (
    <div className="space-y-5">
      <PageHeader title="CRM Follow" description="Coordinate patient follow-ups, external referrals, and campaign leads.">
        {tab === "external" && <>
          {selectedExternal.length > 0 && !showArchivedExternal && (
            <Select value="" onValueChange={(value) => openStatusUpdate(selectedExternal, value as FollowUpStatus)}>
              <SelectTrigger className="w-48"><SelectValue placeholder={`Set status (${selectedExternal.length})`} /></SelectTrigger>
              <SelectContent>{FOLLOWUP_STATUSES.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent>
            </Select>
          )}
          <Button type="button" variant="outline" onClick={() => { setShowArchivedExternal((current) => !current); setSelectedExternal([]); }}>
            {showArchivedExternal ? "Active follow-ups" : `Archived (${archivedExternalFollowUps.length})`}
          </Button>
          <Button type="button" variant="outline" onClick={downloadExternalTemplate}><Download className="mr-2 h-4 w-4" />Template</Button>
          <Button type="button" variant="outline" onClick={() => fileRef.current?.click()}><FileUp className="mr-2 h-4 w-4" />Import Excel</Button>
          <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleExternalImport} />
          <Button type="button" variant="outline" onClick={exportExternal}><Download className="mr-2 h-4 w-4" />Export</Button>
          <Button type="button" onClick={() => { resetFollowUpForm(); setExternalDialogOpen(true); }}><Plus className="mr-2 h-4 w-4" />Add External</Button>
        </>}
        {tab === "leads" && <Badge variant="outline" className="border-amber-500/40 text-amber-700">Mock campaign data</Badge>}
      </PageHeader>

      <section className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-4">
        <SummaryMetric label="Registered patients" value={registeredPatients.length} icon={<Users className="h-4 w-4" />} />
        <SummaryMetric label="Internal follow-ups" value={internalFollowUps.length} icon={<Activity className="h-4 w-4" />} />
        <SummaryMetric label="External follow-ups" value={externalFollowUps.length} icon={<CalendarDays className="h-4 w-4" />} />
        <SummaryMetric label="Campaign leads" value={mockCampaignLeads.length} icon={<Megaphone className="h-4 w-4" />} />
      </section>

      <div className="flex flex-col justify-between gap-3 border-b border-border pb-3 sm:flex-row sm:items-center">
        <Tabs
          value={tab}
          onValueChange={(value) => {
            setSearch("");
            void navigate({ to: "/crm-follow", search: { view: value as ModuleTab } });
          }}
        >
          <TabsList className="grid h-auto w-full grid-cols-3 sm:w-auto">
            <TabsTrigger value="internal" className="gap-2">Internal <span className="text-xs opacity-70">{tabCounts.internal}</span></TabsTrigger>
            <TabsTrigger value="external" className="gap-2">External <span className="text-xs opacity-70">{tabCounts.external}</span></TabsTrigger>
            <TabsTrigger value="leads" className="gap-2">Leads <span className="text-xs opacity-70">{tabCounts.leads}</span></TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="relative w-full sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={(event) => setSearch(event.target.value)} className="pl-9" placeholder={tab === "leads" ? "Search campaign leads" : "Search name, phone, UHID"} />
        </div>
      </div>

      {tab === "internal" && <section className="overflow-hidden rounded-lg border border-border bg-card">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3">
          <div><h2 className="font-semibold">Registered patients</h2><p className="text-sm text-muted-foreground">Schedule and manage follow-ups linked to OPD records.</p></div>
          <Badge variant="outline">{visibleInternalPatients.length} patients</Badge>
        </div>
        <div className="overflow-x-auto"><table className="w-full min-w-210 text-sm">
          <thead className="bg-muted/40 text-left text-xs uppercase text-muted-foreground"><tr><th className="px-4 py-3">Patient</th><th className="px-4 py-3">UHID / OPD</th><th className="px-4 py-3">Doctor / Department</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">Status / Next Date</th><th className="px-4 py-3 text-right">Actions</th></tr></thead>
          <tbody className="divide-y divide-border">
            {loading ? <EmptyRow colSpan={6} message="Loading registered patients..." /> : visibleInternalPatients.length ? visibleInternalPatients.map((patient) => {
              const item = existingForPatient(patient);
              const archivedItem = archivedForPatient(patient);
              const current = item ?? archivedItem;
              return <tr key={patient.id} className="hover:bg-muted/30">
                <td className="px-4 py-3"><div className="font-medium">{patient.name}</div><div className="text-xs text-muted-foreground">{patient.phone || "No phone"}</div></td>
                <td className="px-4 py-3 font-mono text-xs"><div>{patient.uhid || "—"}</div><div className="mt-1 text-muted-foreground">{patient.encounterId || "—"}</div></td>
                <td className="px-4 py-3"><div>{patient.doctorName || "—"}</div><div className="text-xs text-muted-foreground">{patient.departmentName || "—"}</div></td>
                <td className="px-4 py-3">{current ? followUpTypeName(current.followUpType) : "—"}</td>
                <td className="px-4 py-3">{current ? <><Badge variant="outline" className={statusClasses[current.status]}>{current.archived ? "Archived" : current.status}</Badge><div className="mt-1 text-xs text-muted-foreground">{dateLabel(current.nextDate)}</div></> : <span className="text-muted-foreground">Not scheduled</span>}</td>
                <td className="px-4 py-3 text-right"><div className="flex justify-end gap-2"><Button type="button" size="sm" variant="outline" onClick={() => openInternalFollowUp(patient)}>{item ? "Schedule / update" : "Schedule follow-up"}</Button>{current && <DropdownMenu><DropdownMenuTrigger asChild><Button type="button" size="icon" variant="ghost" aria-label={`Actions for ${patient.name}`}><MoreVertical className="h-4 w-4" /></Button></DropdownMenuTrigger><DropdownMenuContent align="end"><DropdownMenuItem onClick={() => setHistoryPatient(current)}><Clock3 className="mr-2 h-4 w-4" />Follow-up history</DropdownMenuItem>{!current.archived && <><DropdownMenuItem onClick={() => openStatusUpdate([current.id], "Scheduled", current)}><CalendarDays className="mr-2 h-4 w-4" />Update status / date</DropdownMenuItem><DropdownMenuItem onClick={() => { setCallPatient(current); setCallOutcome("Answered"); setCallNotes(""); setNextCallAt(""); }}><PhoneCall className="mr-2 h-4 w-4" />Log a call</DropdownMenuItem><DropdownMenuSeparator /><DropdownMenuItem onClick={() => void archiveExternal([current.id])}><Archive className="mr-2 h-4 w-4" />Archive follow-up</DropdownMenuItem></>}{current.archived && <DropdownMenuItem onClick={() => void restoreExternal(current.id)}><RotateCcw className="mr-2 h-4 w-4" />Restore follow-up</DropdownMenuItem>}<DropdownMenuItem className="text-destructive" onClick={() => void deleteExternal(current.id)}><Trash2 className="mr-2 h-4 w-4" />Delete follow-up</DropdownMenuItem></DropdownMenuContent></DropdownMenu>}</div></td>
              </tr>;
            }) : <EmptyRow colSpan={6} message="No registered patients match this search." />}
          </tbody>
        </table></div>
      </section>}

      {tab === "external" && <section className="overflow-hidden rounded-lg border border-border bg-card">
        {selectedExternal.length > 0 && <div className="flex items-center justify-between border-b border-border bg-muted/30 px-4 py-2 text-sm"><span>{selectedExternal.length} external follow-up(s) selected</span><Button type="button" size="sm" variant="ghost" onClick={() => setSelectedExternal([])}>Clear selection</Button></div>}
        <div className="overflow-x-auto"><table className="w-full min-w-200 text-sm">
          <thead className="bg-muted/40 text-left text-xs uppercase text-muted-foreground"><tr><th className="w-10 px-4 py-3"><Checkbox checked={visibleExternalFollowUps.length > 0 && visibleExternalFollowUps.every((item) => selectedExternal.includes(item.id))} onCheckedChange={(checked) => setSelectedExternal(checked ? visibleExternalFollowUps.map((item) => item.id) : [])} /></th><th className="px-4 py-3">Patient</th><th className="px-4 py-3">UHID / Encounter</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">Next Date</th><th className="px-4 py-3">Status</th></tr></thead>
          <tbody className="divide-y divide-border">
            {loading ? <EmptyRow colSpan={6} message="Loading external follow-ups..." /> : visibleExternalFollowUps.length ? visibleExternalFollowUps.map((item) => <tr key={item.id} className="hover:bg-muted/30">
              <td className="px-4 py-3"><Checkbox checked={selectedExternal.includes(item.id)} onCheckedChange={() => selectExternal(item.id)} /></td><td className="px-4 py-3"><div className="font-medium">{item.name}</div><div className="text-xs text-muted-foreground">{item.phone}</div></td><td className="px-4 py-3 font-mono text-xs"><div>{item.uhid || "—"}</div><div className="mt-1 text-muted-foreground">{item.encounterId || "—"}</div></td><td className="px-4 py-3">{followUpTypeName(item.followUpType)}</td><td className="px-4 py-3">{dateLabel(item.nextDate)}</td><td className="px-4 py-3"><Badge variant="outline" className={statusClasses[item.status]}>{item.status}</Badge></td>
            </tr>) : <EmptyRow colSpan={6} message="No external follow-ups yet. Add one manually or import a spreadsheet." />}
          </tbody>
        </table></div>
      </section>}

      {tab === "leads" && <section className="overflow-hidden rounded-lg border border-border bg-card">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3"><div><h2 className="font-semibold">Social promotion leads</h2><p className="text-sm text-muted-foreground">Sample records until the social lead API is connected.</p></div><Badge variant="outline" className="border-amber-500/40 text-amber-700">Mock data</Badge></div>
        <div className="overflow-x-auto"><table className="w-full min-w-215 text-sm">
          <thead className="bg-muted/40 text-left text-xs uppercase text-muted-foreground"><tr><th className="px-4 py-3">Lead</th><th className="px-4 py-3">Channel</th><th className="px-4 py-3">Campaign</th><th className="px-4 py-3">Interest</th><th className="px-4 py-3">Received</th><th className="px-4 py-3">Stage</th><th className="px-4 py-3">Owner</th></tr></thead>
          <tbody className="divide-y divide-border">{mockLeadSearch.map((lead) => <tr key={lead.id} className="hover:bg-muted/30"><td className="px-4 py-3"><div className="font-medium">{lead.name}</div><div className="font-mono text-xs text-muted-foreground">{lead.id} · {lead.phone}</div></td><td className="px-4 py-3"><span className="inline-flex items-center gap-2"><Megaphone className="h-4 w-4 text-muted-foreground" />{lead.channel}</span></td><td className="px-4 py-3">{lead.campaign}</td><td className="px-4 py-3">{lead.interest}</td><td className="px-4 py-3">{new Intl.DateTimeFormat("en", { day: "2-digit", month: "short", hour: "numeric", minute: "2-digit" }).format(new Date(lead.received))}</td><td className="px-4 py-3"><Badge variant="outline">{lead.stage}</Badge></td><td className="px-4 py-3">{lead.owner}</td></tr>)}{!mockLeadSearch.length && <EmptyRow colSpan={7} message="No sample leads match this search." />}</tbody>
        </table></div>
      </section>}

      <Dialog open={Boolean(internalPatient)} onOpenChange={(open) => !open && setInternalPatient(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader><DialogTitle>Internal patient follow-up</DialogTitle><DialogDescription>{internalPatient?.name} · {internalPatient?.uhid || internalPatient?.phone}</DialogDescription></DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Follow-up type"><Select value={followUpForm.followUpType} onValueChange={(value) => setFollowUpForm((current) => ({ ...current, followUpType: value as FollowUpType }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="OPD_REVIEW">OPD Review</SelectItem><SelectItem value="INVESTIGATION_REVIEW">Report Review</SelectItem><SelectItem value="POST_PROCEDURE">Post-Procedure</SelectItem></SelectContent></Select></FormField>
            <FormField label="Next date"><Input type="date" value={followUpForm.nextDate} onChange={(event) => setFollowUpForm((current) => ({ ...current, nextDate: event.target.value }))} /></FormField>
            <div className="sm:col-span-2"><FormField label="Reason / query"><Textarea rows={3} value={followUpForm.query} onChange={(event) => setFollowUpForm((current) => ({ ...current, query: event.target.value }))} placeholder="Reason for the next follow-up" /></FormField></div>
          </div>
          <DialogFooter><Button type="button" variant="outline" onClick={() => setInternalPatient(null)}>Cancel</Button><Button type="button" onClick={() => void saveInternalFollowUp()} disabled={saving}>{saving ? "Saving..." : <><Check className="mr-2 h-4 w-4" />Save follow-up</>}</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={externalDialogOpen} onOpenChange={setExternalDialogOpen}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
          <DialogHeader><DialogTitle>Add external follow-up</DialogTitle><DialogDescription>Enter a referral or patient not yet registered in OPD.</DialogDescription></DialogHeader>
          <FollowUpForm value={followUpForm} onChange={setFollowUpForm} />
          <DialogFooter><Button type="button" variant="outline" onClick={() => setExternalDialogOpen(false)}>Cancel</Button><Button type="button" onClick={() => void saveExternalFollowUp()} disabled={saving}>{saving ? "Saving..." : <><Plus className="mr-2 h-4 w-4" />Add external follow-up</>}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function followUpInput(form: typeof blankFollowUp): FollowUpInput {
  return {
    patientId: form.patientId.trim() || undefined,
    uhid: form.uhid.trim() || undefined,
    encounterId: form.encounterId.trim() || undefined,
    name: form.name.trim(),
    phone: form.phone.trim(),
    age: Number(form.age) || undefined,
    doctorName: form.doctorName.trim() || undefined,
    departmentName: form.departmentName.trim() || undefined,
    followUpType: form.followUpType,
    query: form.query.trim(),
    nextDate: form.nextDate || undefined,
    investigationStatus: form.investigationStatus,
    investigationName: form.investigationName.trim() || undefined,
    investigationOrderId: form.investigationOrderId.trim() || undefined,
    procedureName: form.procedureName.trim() || undefined,
    procedureDate: form.procedureDate || undefined,
    dischargeDate: form.dischargeDate || undefined,
  };
}

function followUpTypeName(type?: FollowUpType) {
  if (type === "INVESTIGATION_REVIEW") return "Report Review";
  if (type === "POST_PROCEDURE") return "Post-Procedure";
  return "OPD Review";
}

function SummaryMetric({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return <div className="flex min-w-0 items-center gap-3 bg-card px-4 py-3"><span className="text-muted-foreground">{icon}</span><div className="min-w-0"><div className="text-lg font-semibold tabular-nums">{value}</div><div className="truncate text-xs text-muted-foreground">{label}</div></div></div>;
}

function EmptyRow({ colSpan, message }: { colSpan: number; message: string }) {
  return <tr><td colSpan={colSpan} className="px-4 py-12 text-center text-muted-foreground">{message}</td></tr>;
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block space-y-1 text-sm"><span className="text-muted-foreground">{label}</span>{children}</label>;
}

function FollowUpForm({
  value,
  onChange,
}: {
  value: typeof blankFollowUp;
  onChange: React.Dispatch<React.SetStateAction<typeof blankFollowUp>>;
}) {
  const update = <K extends keyof typeof blankFollowUp>(field: K, nextValue: (typeof blankFollowUp)[K]) =>
    onChange((current) => ({ ...current, [field]: nextValue }));
  return <div className="space-y-5">
    <section className="space-y-3"><h3 className="text-sm font-semibold">Patient Information</h3><div className="grid gap-3 sm:grid-cols-3">
      <FormField label="Patient ID"><Input value={value.patientId} onChange={(event) => update("patientId", event.target.value)} /></FormField>
      <FormField label="UHID"><Input value={value.uhid} onChange={(event) => update("uhid", event.target.value)} /></FormField>
      <FormField label="Encounter ID"><Input value={value.encounterId} onChange={(event) => update("encounterId", event.target.value)} /></FormField>
      <div className="sm:col-span-2"><FormField label="Patient Name *"><Input value={value.name} onChange={(event) => update("name", event.target.value)} /></FormField></div>
      <FormField label="Phone *"><Input value={value.phone} onChange={(event) => update("phone", event.target.value)} /></FormField>
      <FormField label="Age"><Input type="number" value={value.age} onChange={(event) => update("age", event.target.value)} /></FormField>
      <FormField label="Doctor"><Input value={value.doctorName} onChange={(event) => update("doctorName", event.target.value)} /></FormField>
      <FormField label="Department"><Input value={value.departmentName} onChange={(event) => update("departmentName", event.target.value)} /></FormField>
    </div></section>
    <section className="space-y-3"><h3 className="text-sm font-semibold">Follow-Up Details</h3><div className="grid gap-3 sm:grid-cols-2">
      <FormField label="Follow-Up Type"><Select value={value.followUpType} onValueChange={(next) => update("followUpType", next as FollowUpType)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="OPD_REVIEW">OPD Review</SelectItem><SelectItem value="INVESTIGATION_REVIEW">Report Review</SelectItem><SelectItem value="POST_PROCEDURE">Post-Procedure</SelectItem></SelectContent></Select></FormField>
      <FormField label="Next Date"><Input type="date" value={value.nextDate} onChange={(event) => update("nextDate", event.target.value)} /></FormField>
      <div className="sm:col-span-2"><FormField label="Reason / Patient Query"><Textarea rows={2} value={value.query} onChange={(event) => update("query", event.target.value)} /></FormField></div>
    </div></section>
    {value.followUpType === "INVESTIGATION_REVIEW" && <section className="space-y-3"><h3 className="text-sm font-semibold">Investigation Details</h3><div className="grid gap-3 sm:grid-cols-3">
      <FormField label="Investigation Status"><Select value={value.investigationStatus} onValueChange={(next) => update("investigationStatus", next as InvestigationStatus)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{investigationStatuses.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select></FormField>
      <FormField label="Investigation Name *"><Input value={value.investigationName} onChange={(event) => update("investigationName", event.target.value)} /></FormField>
      <FormField label="Order ID"><Input value={value.investigationOrderId} onChange={(event) => update("investigationOrderId", event.target.value)} /></FormField>
    </div></section>}
    {value.followUpType === "POST_PROCEDURE" && <section className="space-y-3"><h3 className="text-sm font-semibold">Procedure / Discharge</h3><div className="grid gap-3 sm:grid-cols-3">
      <FormField label="Procedure / Surgery"><Input value={value.procedureName} onChange={(event) => update("procedureName", event.target.value)} /></FormField>
      <FormField label="Procedure Date"><Input type="date" value={value.procedureDate} onChange={(event) => update("procedureDate", event.target.value)} /></FormField>
      <FormField label="Discharge Date"><Input type="date" value={value.dischargeDate} onChange={(event) => update("dischargeDate", event.target.value)} /></FormField>
    </div></section>}
  </div>;
}